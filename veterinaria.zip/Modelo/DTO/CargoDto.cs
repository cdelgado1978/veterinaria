﻿namespace Veterinaria.Modelo.DTO
{
    public class CargoDto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public bool Inactivo { get; set; }
    }
}