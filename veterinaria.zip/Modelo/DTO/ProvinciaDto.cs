﻿namespace Veterinaria.Modelo.DTO
{


    public class ProvinciaDto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public bool Inactivo { get; set; }
    }
}